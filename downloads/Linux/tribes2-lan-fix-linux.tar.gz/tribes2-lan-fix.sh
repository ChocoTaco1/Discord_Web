#!/bin/sh
export PATH="$PATH:."
if [ -f "tribes2d.dynamic" ]; then
	xdelta3 decode -s tribes2d.dynamic tribes2-lan-fix-linux.xdelta tribes2d-lan.dynamic && \
	chmod 755 tribes2d-lan.dynamic
else
	echo "Can't find tribes2d.dynamic!  Are you running the script in the tribes2 directory?" >&2
	exit 1
fi
